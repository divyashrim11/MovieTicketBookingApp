

//
//  MovieCollecViewController.swift
//  Group01_TicketBookingApp
//
//  Created by Moka,Divya Shree on 4/25/23.
//




import UIKit

class DigitsOnlyTextField: UITextField {
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.keyboardType = .numberPad
        self.addTarget(self, action: #selector(validateInput), for: .editingChanged)
    }
    
    @objc private func validateInput() {
        guard let text = self.text else { return }
        let digitsOnly = text.filter { $0.isNumber }
        self.text = digitsOnly
    }
    
}
