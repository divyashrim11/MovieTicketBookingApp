//
//  TicketViewController.swift
//  Group01_TicketBookingApp
//
//  Created by Moka,Divya Shree on 4/25/23.
//

import UIKit

class TicketViewController: UIViewController {

    @IBOutlet weak var selectedmovieImageView: UIImageView!
    
    @IBOutlet weak var enterticketCount: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        self.selectedmovieImageView.image = UIImage(named: selectedMovie.image)

        // Do any additional setup after loading the view.
    }
    
    @IBAction func ticketviewNext(_ sender: UIButton) {
    
        if(self.enterticketCount.text!.isEmpty) {
            showAlert(message: "Please enter number of tickets")
            return
        }else {
            noOfTickets =  self.enterticketCount.text!
           
            self.performSegue(withIdentifier: "TicketPaymentSegue", sender: self)
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

var noOfTickets = ""
