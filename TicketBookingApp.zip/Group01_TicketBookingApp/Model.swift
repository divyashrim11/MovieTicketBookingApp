

//
//  MovieCollecViewController.swift
//  Group01_TicketBookingApp
//
//  Created by Moka,Divya Shree on 4/25/23.
//



struct User {
    
    var userName:String
    var pass:String
    
}

var users : [User] = [

    User(userName: "user1", pass: "1111"),
    
    User(userName: "user2", pass: "1111"),
    
    User(userName: "user3", pass: "1111")
    
]

 


struct Movie {
    let name: String
    let price: Double
    let rating: Double
    let showTime: String
    let image: String
}



let theGodfather = Movie(name: "The Godfather", price: 14.99, rating: 9.2, showTime: "3:00 PM", image: "1")
let shawshankRedemption = Movie(name: "The Shawshank Redemption", price: 12.99, rating: 9.3, showTime: "5:30 PM", image: "2")
let darkKnight = Movie(name: "The Dark Knight", price: 11.99, rating: 9.0, showTime: "7:00 PM", image: "3")
let forrestGump = Movie(name: "Forrest Gump", price: 9.99, rating: 8.8, showTime: "8:30 PM", image: "4")
let titanic = Movie(name: "Titanic", price: 10.99, rating: 8.7, showTime: "10:00 PM", image: "5")
let starWars = Movie(name: "Star Wars: Episode IV", price: 13.99, rating: 8.6, showTime: "11:30 PM", image: "6")

let movies = [theGodfather, shawshankRedemption, darkKnight, forrestGump, titanic, starWars]
