//
//  PaymentViewController.swift
//  Group01_TicketBookingApp
//
//  Created by Moka,Divya Shree on 4/25/23.
//

import UIKit

class PaymentViewController: UIViewController {

    @IBOutlet weak var accountNumber: UITextField!
    
    @IBOutlet weak var routingNumber: UITextField!
    
    @IBOutlet weak var numberofTickets: UILabel!
    
    @IBOutlet weak var prieoftickets: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        var  totalPrice = selectedMovie.price
        
        
        if let noOfTickets = Double(noOfTickets) {
           
            totalPrice =  totalPrice * noOfTickets
        }
        

       
        self.numberofTickets.text = "Number of Tickets: " + noOfTickets
        
        self.prieoftickets.text = "Total Price of the Tickets: " + totalPrice.description
        // Do any additional setup after loading the view.
    }
    

    @IBAction func makePayment(_ sender: UIButton) {
        
        if(self.accountNumber.text!.isEmpty) {
            showAlert(message: "Please enter account Number")
            return
        }
        
        if(self.routingNumber.text!.isEmpty) {
            
            showAlert(message: "Please enter routing Number")
            return
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
