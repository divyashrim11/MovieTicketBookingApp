//
//  HelloViewController.swift
//  Group01_TicketBookingApp
//
//  Created by Moka,Divya Shree on 4/25/23.
//

import UIKit

class HelloViewController: UIViewController {
    
    @IBOutlet weak var helloUserNameOutlet: UILabel!
    

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        
        let text = "Hey \(currentUser.userName) Are you trying to book your movie tickets? Click on next to continue!"
        
        helloUserNameOutlet.text = text
         
        
    }
    
    
    
  
    @IBAction func helloViewNextButton(_ sender: UIButton) {
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
