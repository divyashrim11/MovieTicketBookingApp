//
//  MovieCollectionViewCell.swift
//  Group01_TicketBookingApp
//
//  Created by Moka,Divya Shree on 4/25/23.
//
 
import UIKit

class MovieListViewController: UIViewController {
 

    @IBOutlet weak var tableView: UITableView!
    
  
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.dataSource = self
        tableView.delegate = self
        //tableView.register(UITableViewCell.self, forCellReuseIdentifier: "tableViewCell")
    }
    
}

extension MovieListViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return movies.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "tableViewCell", for: indexPath)
        let movie = movies[indexPath.row]
        
        cell.textLabel?.text = movie.name
        cell.detailTextLabel?.text = "$" +  movie.price.description
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
         
        selectedMovie = movies[indexPath.row]
        
        performSegue(withIdentifier: "MovieDetailsViewController", sender: self)
    }
}


var selectedMovie : Movie!
