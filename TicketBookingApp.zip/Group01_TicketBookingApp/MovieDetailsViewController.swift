//
//  MovieCollecViewController.swift
//  Group01_TicketBookingApp
//
//  Created by Moka,Divya Shree on 4/25/23.
//

import UIKit

class MovieDetailsViewController: UIViewController {
    
    @IBOutlet weak var movieImage: UIImageView!
    @IBOutlet weak var movieName1: UILabel!
    
    @IBOutlet weak var priceOL: UILabel!
    
    @IBOutlet weak var imdbratingOl: UILabel!
    
    @IBOutlet weak var showtime1OL: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        self.movieName1.text = "Movie Name: " + selectedMovie.name
        self.priceOL.text = "Price $ " + selectedMovie.price.description
        self.imdbratingOl.text = "Rating: " + selectedMovie.rating.description
        self.movieImage.image = UIImage(named: selectedMovie.image)
        self.showtime1OL.text = "Show Time: " +  selectedMovie.showTime
    }
    
    
   

}
