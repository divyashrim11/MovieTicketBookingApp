//
//  ViewController.swift
//  Group01_TicketBookingApp
//
//  Created by Moka,Divya Shree on 4/25/23.
//

import UIKit

class HomeViewController: UIViewController {
    
    @IBOutlet weak var userNameOL: UITextField!
    
    @IBOutlet weak var passwordOL: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        // Do any additional setup after loading the view.
    }
    
    @IBAction func loginButton(_ sender: UIButton) {
            
        if(userNameOL.text!.isEmpty) {
            showAlert(message: "Please enter userName")
            return
        }
            
        if(passwordOL.text!.isEmpty) {
            showAlert(message: "Please enter your password")
            return
        }
            
        // Check if the user already exists
        if let user = users.first(where: { $0.userName == userNameOL.text }) {
            if user.pass == passwordOL.text {
                currentUser = user
            } else {
                // Password didn't match, show an alert
                showAlert(message: "Incorrect password")
            }
        } else {
            // User doesn't exist, show an alert
            showAlert(message: "User doesn't exist")
        }
    }

}



var currentUser  :   User!
