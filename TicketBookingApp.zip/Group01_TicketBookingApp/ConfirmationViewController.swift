//
//  ConfirmationViewController.swift
//  Group01_TicketBookingApp
//
//  Created by Moka,Divya Shree on 4/25/23.
//

import UIKit

class ConfirmationViewController: UIViewController {

    @IBOutlet weak var movieName2: UILabel!
    
    @IBOutlet weak var movieImage: UIImageView!
    @IBOutlet weak var showTime2: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        self.movieName2.text = "Movie Name: " + selectedMovie.name
        self.showTime2.text = "Show Time: " + selectedMovie.showTime
        movieImage.image = UIImage(named: selectedMovie.image)
        
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
